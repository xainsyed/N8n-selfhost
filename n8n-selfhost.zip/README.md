# n8n Selfhost Deployment (Railway/Render Ready)

## Steps
1. Upload this repo to GitHub.
2. Deploy on Railway or Render.
3. Add environment variables (from guide).
4. Open deployed URL → login using admin/admin123.
